<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    // ─── Login ───────────────────────────────────────────────────────────────

    public function login(Request $request)
    {
        $request->validate([
            'email'    => 'required|email',
            'password' => 'required',
        ]);

        $user = User::where('email', $request->email)->first();

        if (!$user || !Hash::check($request->password, $user->getAuthPassword())) {
            return response()->json(['message' => 'Kredensial tidak valid.'], 401);
        }

        $token = \Tymon\JWTAuth\Facades\JWTAuth::fromUser($user);

        // Generate Refresh Token
        $rawRefreshToken = \Illuminate\Support\Str::random(64);
        \App\Models\RefreshToken::create([
            'user_id' => $user->id,
            'token_hash' => hash('sha256', $rawRefreshToken),
            'expires_at' => now()->addDays(7),
        ]);

        return response()->json([
            'access_token' => $token,
            'refresh_token' => $rawRefreshToken,
            'token_type' => 'bearer',
            'expires_in' => config('jwt.ttl') * 60,
            'user' => [
                'name' => $user->name,
                'role' => $user->role,
                'email' => $user->email
            ]
        ]);
    }

    public function register(Request $request)
    {
        $request->validate([
            'name'     => 'required|string|max:255',
            'phone'    => 'required|string',
            'email'    => 'required|email|unique:users,email',
            'password' => 'required|min:8|confirmed',
        ]);

        $user = User::create([
            'name' => $request->name,
            'phone' => $request->phone,
            'email' => $request->email,
            'password_hash' => Hash::make($request->password),
            'role' => 'CUSTOMER',
        ]);

        $token = \Tymon\JWTAuth\Facades\JWTAuth::fromUser($user);

        return response()->json([
            'success' => true,
            'message' => 'Registrasi berhasil.',
            'access_token' => $token,
            'token_type' => 'bearer'
        ], 201);
    }

    public function refresh(Request $request)
    {
        $request->validate(['refresh_token' => 'required']);

        $hashed = hash('sha256', $request->refresh_token);
        $record = \App\Models\RefreshToken::where('token_hash', $hashed)
            ->whereNull('revoked_at')
            ->where('expires_at', '>', now())
            ->first();

        if (!$record) {
            return response()->json(['message' => 'Refresh token tidak valid atau kadaluarsa.'], 401);
        }

        $user = User::find($record->user_id);
        
        // Rotate: revoke lama, buat baru
        $record->update(['revoked_at' => now()]);
        
        $newRaw = \Illuminate\Support\Str::random(64);
        \App\Models\RefreshToken::create([
            'user_id' => $user->id,
            'token_hash' => hash('sha256', $newRaw),
            'expires_at' => now()->addDays(7),
        ]);

        $newToken = \Tymon\JWTAuth\Facades\JWTAuth::fromUser($user);

        return response()->json([
            'access_token' => $newToken,
            'refresh_token' => $newRaw,
            'token_type' => 'bearer',
            'expires_in' => config('jwt.ttl') * 60
        ]);
    }

    public function logout(Request $request)
    {
        if ($request->refresh_token) {
            $hashed = hash('sha256', $request->refresh_token);
            \App\Models\RefreshToken::where('token_hash', $hashed)->update(['revoked_at' => now()]);
        }

        try {
            \Tymon\JWTAuth\Facades\JWTAuth::invalidate(\Tymon\JWTAuth\Facades\JWTAuth::getToken());
        } catch (\Exception $e) {
            // Token already invalid or not provided
        }

        return response()->json(['message' => 'Logged out successfully.']);
    }

    /**
     * Send password reset link. [SEDANG #8]
     */
    public function sendResetLink(Request $request)
    {
        $request->validate(['email' => 'required|email']);

        $status = \Illuminate\Support\Facades\Password::sendResetLink(
            $request->only('email')
        );

        return $status === \Illuminate\Support\Facades\Password::RESET_LINK_SENT
            ? response()->json(['message' => 'Link reset dikirim ke email.'])
            : response()->json(['message' => 'Email tidak ditemukan.'], 404);
    }

    /**
     * Handle the password reset submission. [Fase 13]
     */
    public function resetPassword(Request $request)
    {
        $request->validate([
            'token' => 'required',
            'email' => 'required|email',
            'password' => 'required|min:8|confirmed',
        ]);

        $status = \Illuminate\Support\Facades\Password::reset(
            $request->only('email', 'password', 'password_confirmation', 'token'),
            function ($user, $password) {
                $user->forceFill([
                    'password_hash' => Hash::make($password)
                ])->save();
            }
        );

        return $status === \Illuminate\Support\Facades\Password::PASSWORD_RESET
            ? response()->json(['message' => 'Password berhasil direset.'])
            : response()->json(['message' => __($status)], 400);
    }
}
