<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Menambahkan PENDING_VERIFICATION ke enum status
        DB::statement("ALTER TABLE orders MODIFY COLUMN status ENUM('NEW', 'PENDING_VERIFICATION', 'PROCESSING', 'DELIVERING', 'DONE', 'REJECTED') DEFAULT 'NEW'");
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Mengembalikan ke enum lama
        DB::statement("ALTER TABLE orders MODIFY COLUMN status ENUM('NEW', 'PROCESSING', 'DELIVERING', 'DONE', 'REJECTED') DEFAULT 'NEW'");
    }
};
